import socket
import threading
import tkinter as tk
from tkinter import scrolledtext

TCP_ADDRESS = ('localhost', 54505)

# Shared list - store the messages
chat_message: list = []
lock = threading.Lock() # Lock - prevents race condition when accessing chat_messages

# Create a server socket(TCP)
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(TCP_ADDRESS)
server_socket.listen(3)

clients = [] # list - keep track of number of players 

# Handle communication - client
def broadcast(message) -> None:
    with lock: # Thread safe sending
        for client in clients:
            client.sendall(message.encode())

def handle_client(conn, addr) -> None:
    while True:
        try:
            message = conn.recv(1024).decode()
            if not message:
                break
            with lock:
                chat_message.append(f"Client: {message}")
            update_chat_window()
            broadcast(f"")
        except:
            break

def accept_connection() -> None:
    while True:
        conn, addr = server_socket.accept()
        clients.append(conn)
        threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()
        
def send_message() -> None:
    message = input_field.get()
    if message: 
        with lock:
            chat_message.append(message)
            update_chat_window()
            broadcast("")
            input_field.delete(0, tk.END) # It clears the input field after sending

def update_chat_window() -> None:
    chat_display.config(state=tk.NORMAL) # Enabling the editing text area
    chat_display.delete(1, tk.END) # Clears the chat display
    with lock:
        for message in chat_message:
            chat_display.insert(tk.END, message + '\n')
        chat_display.config(state=tk.DISABLED)

# GUI Setup
root = tk.Tk() # Main application window
root.title("Server Side Chat")

# Scrollable text
chat_display = scrolledtext.ScrolledText(root, width=50, height=30, state=tk.DISABLED)
chat_display.pack(padx=10, pady=10)

# Input field
input_field = tk.Entry(root, width=40)
input_field.pack(side=tk.LEFT, padx=(10, 0), pady=(0, 10))

# Start accepting connections
threading.Thread(target=accept_connection, daemon=True).start()

root.mainloop()










