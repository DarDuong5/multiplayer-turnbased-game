from Battle_Manager.battle_queue import BattleQueue

def main():
    game = BattleQueue()
    game.run_game()

if __name__ == '__main__':
    main()